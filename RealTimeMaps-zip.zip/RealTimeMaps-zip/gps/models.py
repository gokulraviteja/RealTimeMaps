from django.db import models

# Create your models here.

class Ping(models.Model):

    # basic details
    lat = models.CharField(max_length=2000)
    lon = models.CharField(max_length=2000)
    lat_ip = models.CharField(max_length=2000)
    lon_ip = models.CharField(max_length=20000)
    timestamp = models.CharField(max_length=2000)




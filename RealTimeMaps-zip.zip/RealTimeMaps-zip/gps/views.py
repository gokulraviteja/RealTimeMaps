from django.shortcuts import render

# Create your views here.
import json
from .models import Ping
from django.http import HttpResponse
import  time




def home(request):
    return render(request , "home.html")



def store_pings(request , p):
    print("Received : p : ", p)
    arr = p.split(",")
    lat = arr[0]
    lon = arr[1]
    lat_ip = arr[2]
    lon_ip = arr[3]
    ts=time.time()
    ts=str(int(ts))
    p = Ping.objects.create(lat=lat , lon =lon , lat_ip=lat_ip , lon_ip=lon_ip, timestamp=ts)
    p.save()
    return HttpResponse(json.dumps({}))


def view_pings(request):
    pings = Ping.objects.all()
    return render(request , "view_pings.html",{"pings":pings})



def delete_all(request):
    arr = Ping.objects.all()
    for i in arr:
        i.delete()
    return HttpResponse("Deleted all records")

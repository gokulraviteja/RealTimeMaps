

from django.contrib import admin
from django.urls import path
from . import views

urlpatterns = [
    path('', views.home),
    path('ping/<str:p>', views.store_pings),
    path('delete_all', views.delete_all),
    path('view_pings', views.view_pings)
]


var  global_lat = ""
var  global_lon = ""

var  global_lat_ip = ""
var  global_lon_ip = ""


function getLocation() {
    console.log("Getting location!")
    if (navigator.geolocation) {
        console.log("Supported")
        navigator.geolocation.getCurrentPosition(showPosition);
    } else {
        window.alert( "Geolocation is not supported by this browser.");
    }
    return false;
}

function showPosition(position) {
    global_lat =  position.coords.latitude
    global_lon =  position.coords.longitude
}

function getLocationApi(){
    ipLookUp()
}


const ipLookUp = async () => {

    const res = await fetch('http://ip-api.com/json');
    response = await res.json();
    global_lat_ip = response.lat
    global_lon_ip = response.lon

};

const sendToBackend = async (l1,l2,l3,l4) => {
    ans=l1+','+l2+','+l3+','+l4
    const res = await fetch('http://localhost:8000/ping/'+ans);
};

function getPings(){
    console.log("Retrieving location...")
    getLocation()
    getLocationApi()
    console.log(global_lat , global_lon , global_lat_ip , global_lon_ip )
    document.getElementById("location").innerText = ""
    document.getElementById("location").innerText = global_lat+","+global_lon
    sendToBackend(global_lat , global_lon , global_lat_ip , global_lon_ip )
}



getPings()

setInterval(getPings, 5000)